# JARVIS Advanced Edition — GitHub setup

## Upload
1. Back up the currently working GitHub repository.
2. Extract this ZIP and upload the **contents of `Jarvis--main`** to the repository root (including `.github`).
3. Commit to `main`; the existing Actions workflow runs `gradle assembleDebug`.
4. Download the `JARVIS-APK` artifact from the successful Actions run.

## Gemini backend (required for online AI)
1. Create a Cloudflare Worker and paste `backend/worker.js`.
2. In Worker Settings → Variables and Secrets, add secret `GEMINI_API_KEY` with your Google AI Studio API key. Do not commit the key.
3. Deploy the Worker and copy its HTTPS URL.
4. In `app/src/main/java/com/kishore/jarvis/MainActivity.kt`, replace `https://YOUR-PRIVATE-BACKEND-URL` with the Worker URL. Commit and rebuild.
5. Review current Gemini pricing, model availability, quotas and Google Search grounding availability in Google AI Studio documentation. Free quotas can change.

## Background wake phrase
- Open JARVIS and tap **WAKE WORD** while the activity is visible and microphone permission is granted. Android requires a foreground service and persistent notification; say “Hey JARVIS” followed by a command.
- This implementation continuously re-arms Android `SpeechRecognizer`. It may use the device speech provider/network, consumes battery, and is not a dedicated offline hotword DSP engine. It can be stopped from Android Settings → Apps → JARVIS → Force stop, or by adding a stop control in a later UI update.
- Android 14+ restricts starting microphone foreground services from the background. Start it from the visible app. Xiaomi battery management may still stop it; allow background activity/autostart where available.
- Speech recognizer availability and supported languages depend on the installed speech provider. The current wake listener uses `en-IN`.

## Included capabilities and boundaries
- Existing project: local commands, notes, reminders, app launch, contact lookup/dialer, speech input/output, local memory and AI client.
- Added: user-started microphone foreground wake listener, wake phrase dispatch, Cloudflare Worker Gemini proxy with Google Search grounding, setup notes.
- Calls open the dialer; the user confirms. Contact lookup needs runtime READ_CONTACTS permission (the current UI may require a future permission flow).
- Messaging modules prepare/open supported apps; silent sending is not guaranteed or implemented for every app.
- App task planner is not universal UI automation. Third-party automation requires app-specific APIs or an explicitly enabled AccessibilityService and user consent.
- Incoming call answer/reject/end, universal device control, full autonomous booking/payment, and SAP/JSA are not implemented in this package. SAP/JSA excluded as requested.
- Action confirmation UI is present in the project, but every sensitive action path must be wired and tested before relying on it.

## Security
- Never place API keys in Kotlin, `local.properties`, or a public GitHub repository. Use Cloudflare Worker secrets.
- Add authentication/rate limiting before exposing a public Worker to others. This starter Worker uses permissive CORS and is intended for personal testing, not production.
- Review permissions and test on-device. A successful GitHub build proves compilation, not that all device features work.


## Additional integrated controls (November 2026 build)

This source adds an **optional Accessibility Service** for a small, explicit set of Android navigation actions. In the app, tap **SET UP ACCESSIBILITY CONTROLS**, then find and enable **JARVIS navigation controls** in Android Accessibility settings. You can disable it there at any time.

Supported commands when the service is enabled:
- “go back”
- “go home”
- “show recent apps”
- “show notifications”
- “open quick settings”
- “show power menu”

Privacy boundary: this service is configured with `canRetrieveWindowContent=false`. It does not read screen text, inspect other apps, click arbitrary buttons, or type into other apps. It is not a universal app-automation engine. The four main controls are arranged in two rows for phone screens.

## Features that are not yet implemented

The project is **not** a complete hands-free phone operator. Incoming call answer/reject/end controls are not implemented; Android generally requires a properly configured default dialer / `InCallService` and additional testing. Messages are prepared in supported app or share interfaces and still require the user to review and send them. WhatsApp/Telegram/Instagram/Messenger do not provide a universal free API for silent sending. Payment, booking, OTP, CAPTCHA, and purchase confirmation remain manual. The on-device confirmation dialog is not yet connected to a complete action execution pipeline. Wake-word recognition is a user-started foreground service based on Android SpeechRecognizer, not a dedicated offline hotword engine; it may use network, consume battery, and be restricted by Xiaomi background policies. Wake commands are currently delivered to the activity receiver, so command handling is not guaranteed after Android destroys the activity.

## Build and test status

The ZIP archive structure has been checked, but this environment does not have a Gradle executable or Android SDK, so this revision has **not** been compiled here. Use the included GitHub Actions workflow to compile it. Treat the APK as unverified until Actions reports a successful build and the APK is installed and tested on the Redmi 13 5G. Do not assume every listed command works until tested on-device.

---

## Integrated permission-gated capabilities (development build)

This revision adds Android-owned handoff flows. JARVIS opens the relevant app/system screen; it does not silently send messages, place calls, make purchases, book services, or change protected settings.

### Optional Android permissions and roles

| Capability | Android permission / user action | What JARVIS does |
|---|---|---|
| Voice input and wake listener | Microphone permission; user starts foreground listener | Uses Android SpeechRecognizer. This is not a dedicated offline hotword engine and may use network/battery. |
| App navigation controls | User manually enables JARVIS in Accessibility settings | Supports Back, Home, Recents, Notifications, Quick Settings and Power Menu. Screen reading/tapping is deliberately not enabled. |
| Contact lookup | READ_CONTACTS runtime permission (must be granted by user) | Looks up a contact and opens the dialer; user places the call. |
| Incoming call controls | User must explicitly choose JARVIS as the default Phone/Dialer app; Android controls the role prompt | InCallService posts Answer/Reject notification actions. Device/OEM behavior and notification permission affect display. |
| Reminders | Notification permission; exact-alarm access may be required by Android settings | Schedules local reminders. Verify alarm/reminder behavior on the device. |
| Internet / Maps | Internet and an installed browser/maps app | Opens search, map results or navigation; user reviews route. |
| SMS / WhatsApp / Telegram | Installed target app; user selects recipient and presses Send | Opens a compose/share flow; no silent sending. |
| Email | Installed mail app | Opens a draft; user reviews and sends. |
| Calendar | Calendar app and its own permissions as required | Opens event editor; user reviews and saves. |
| Wi-Fi / network / volume settings | Android system settings/panel | Opens system UI; user makes the change. |

### Example voice/text commands

- `search web for heat exchanger`
- `navigate to MNNIT Allahabad`
- `find petrol pump on map`
- `send sms to 9876543210 saying I am on my way`
- `share on whatsapp I will reach in ten minutes`
- `share on telegram Meeting starts at 3 PM`
- `share message Hello everyone`
- `email person@example.com subject Meeting body Please confirm the time`
- `create calendar event Project review`
- `open wifi settings`
- `open internet settings`
- `open volume settings`

### Important boundaries

- Do not enable Accessibility or make JARVIS your default dialer unless you understand and want those permissions. You can revoke them in Android Settings at any time.
- Incoming call actions are available only if Android accepts JARVIS as the default dialer and the OEM supports the service behavior. The Android system may still show its own call UI.
- The current Accessibility Service intentionally cannot inspect screen text or tap arbitrary app controls. That prevents broad access to private screens and avoids unreliable/unsafe universal automation.
- WhatsApp/Telegram sharing uses official app/web handoff. It cannot guarantee the recipient is selected or that a message is sent.
- Banking, UPI, payment, OTP, CAPTCHA, purchases, bookings and final confirmations remain manual.
- This build is source-integrated but has not been verified by a successful Android/Gradle build in this environment. GitHub Actions must be used to compile and test it before installing.
- `MainActivity.kt` still needs your deployed Cloudflare Worker URL in place of `https://YOUR-PRIVATE-BACKEND-URL`. Keep the Gemini API key only as a Worker secret; never put it in the Android app or GitHub source.


## Optional WhatsApp / Telegram accessibility-assisted message flow with voice approval

This is an experimental, user-enabled assistive workflow, not an official WhatsApp/Telegram API. Enable **JARVIS navigation controls** manually in Android Accessibility settings. Android grants the service access to visible UI content in the allowlisted apps (WhatsApp `com.whatsapp` and Telegram `org.telegram.messenger`). The service attempts to fill a message draft; it does not send at that stage.

Example commands:
- `send WhatsApp to +919876543210 saying Hello, I will reach at 6.`
- `send Telegram to @username saying Hello, are you available?`

When the draft editor is filled, JARVIS reads the requested platform, recipient string, and complete message aloud. It then starts speech recognition and waits for one of these explicit phrases:
- `Jarvis, confirm send` (also accepts `confirm send`)
- `Jarvis, cancel` (also accepts `cancel send`)

Only the exact approval phrase triggers an attempt to tap the Send control. Any unclear speech, speech-recognition error, app mismatch, missing accessibility service, or expired request cancels or fails closed. A pending request expires after 30 seconds. The notification provides a Cancel action only; it does not provide a tap-to-send action. Microphone permission and manually enabled Accessibility are both required. Android may restrict microphone use while JARVIS is backgrounded; if voice capture is blocked, the request is cancelled and you must not assume a message was sent.

Safety and limitations:
- Before approving, visually check that the actual open chat is the intended recipient. The spoken recipient is the recipient string from your command; JARVIS cannot independently prove the account identity from the app UI.
- The accessibility workflow is experimental and can break when WhatsApp/Telegram changes their UI, language, layout, or package name. Cloned apps, dual-app variants and WhatsApp Business are not covered.
- The Send button is located by its accessible label; if it cannot be identified safely, no send action is attempted.
- A successful button click does not prove delivery. Verify the message status in the app.
- Do not use this for bulk messaging. Respect recipients' consent and each platform's terms.
- You can disable the Accessibility Service at any time in Android Accessibility settings and revoke microphone permission in App permissions.

Official WhatsApp Business Cloud API or Telegram Bot API integrations are separate alternatives for supported business/bot use cases and require account setup and credentials.
