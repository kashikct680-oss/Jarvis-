# JARVIS Advanced Edition

Android source project. Build the debug APK using the included GitHub Actions workflow.

## Cloudflare Gemini backend
- Worker entry point: `backend/worker.js`
- Worker config: `backend/wrangler.toml`
- Android endpoint is configured in `MainActivity.kt` as `https://jarvis.kashikct680.workers.dev`.
- In Cloudflare Worker Settings > Variables and Secrets, add `GEMINI_API_KEY` as a **Secret** for Production.
- Never put the Gemini API key in Android source code or commit it to GitHub.
- The Worker currently allows public POST requests and wildcard CORS. Add appropriate access controls/rate limiting before sharing the app publicly; a public endpoint can incur API usage.

## Build
Push the repository to GitHub on branch `main`, then open Actions and run **Build JARVIS APK**. Download the `JARVIS-APK` artifact after the workflow succeeds.

## Device setup
- Grant microphone permission for speech input.
- Start/stop wake listening from the app. Android foreground microphone service restrictions apply; the user must start it while the app is in an allowed state.
- Enable JARVIS navigation controls manually under Android Accessibility settings only if you choose to use them.
- The optional accessibility integration prepares supported WhatsApp/Telegram message drafts. It requires the relevant app UI to be open and compatible. It must not be treated as guaranteed sending automation.
- Voice approval is designed to require the phrase `Jarvis, confirm send`; `Jarvis, cancel` cancels. Always verify the recipient and complete message before approving.
- Phone calls and other actions remain subject to Android roles, permissions, and confirmation prompts.

## Important limitations
- This source has been assembled to resolve the missing service/UI integration reported in the supplied GitHub Actions log. It has **not** been compiled in this environment. A successful GitHub Actions build is still required to verify it.
- Android speech recognition may use the device's recognition provider/network and is not a dedicated offline hotword engine.
- Accessibility UI automation is inherently app-version and screen-layout dependent.
- Gemini API free-tier availability and limits depend on Google's current terms and quota.
