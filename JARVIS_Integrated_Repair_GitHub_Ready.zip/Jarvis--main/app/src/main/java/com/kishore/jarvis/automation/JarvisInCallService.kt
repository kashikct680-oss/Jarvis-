package com.kishore.jarvis.automation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** Incoming-call controls are available only after the user explicitly chooses JARVIS as default phone app. */
class JarvisInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        activeCall = call
        showCallNotification(this, call)
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                if (state == Call.STATE_DISCONNECTED || state == Call.STATE_DISCONNECTING) {
                    NotificationManagerCompat.from(this@JarvisInCallService).cancel(CALL_NOTIFICATION_ID)
                    if (activeCall === call) activeCall = null
                }
            }
        })
    }

    override fun onCallRemoved(call: Call) {
        if (activeCall === call) activeCall = null
        NotificationManagerCompat.from(this).cancel(CALL_NOTIFICATION_ID)
        super.onCallRemoved(call)
    }

    companion object {
        const val ACTION_ANSWER = "com.kishore.jarvis.CALL_ANSWER"
        const val ACTION_REJECT = "com.kishore.jarvis.CALL_REJECT"
        private const val CHANNEL_ID = "jarvis_incoming_calls"
        private const val CALL_NOTIFICATION_ID = 8401
        @Volatile var activeCall: Call? = null
            private set

        fun performAction(action: String) {
            val call = activeCall ?: return
            when (action) {
                ACTION_ANSWER -> call.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY)
                ACTION_REJECT -> call.reject(false, null)
            }
        }

        private fun showCallNotification(context: Context, call: Call) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Incoming calls", NotificationManager.IMPORTANCE_HIGH))
            }
            val details = call.details
            val caller = details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: "Unknown caller"
            fun actionIntent(action: String, request: Int): PendingIntent {
                val intent = Intent(context, CallActionReceiver::class.java).setAction(action)
                return PendingIntent.getBroadcast(context, request, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            }
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle("Incoming call")
                .setContentText(caller)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .addAction(android.R.drawable.sym_action_call, "Answer", actionIntent(ACTION_ANSWER, 1))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Reject", actionIntent(ACTION_REJECT, 2))
                .build()
            try { NotificationManagerCompat.from(context).notify(CALL_NOTIFICATION_ID, notification) } catch (_: SecurityException) { }
        }
    }
}

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        intent.action?.let(JarvisInCallService::performAction)
    }
}
