package com.kishore.jarvis.automation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Notification offers cancellation only; sending requires the spoken approval phrase. */
class MessagingActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == ACTION_CANCEL) JarvisAccessibilityService.cancelPendingMessage()
    }

    companion object {
        const val ACTION_CANCEL = "com.kishore.jarvis.action.CANCEL_MESSAGE"
    }
}
