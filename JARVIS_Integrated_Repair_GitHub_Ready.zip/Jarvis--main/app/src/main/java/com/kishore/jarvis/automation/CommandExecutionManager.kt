package com.kishore.jarvis.automation

import android.content.Context
import com.kishore.jarvis.core.CommandRouter
import com.kishore.jarvis.core.CommandType
import com.kishore.jarvis.memory.LocalStorage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CommandExecutionResult(
    val success: Boolean,
    val response: String,
    val requiresConfirmation: Boolean = false
)

class CommandExecutionManager(context: Context) {

    private val appLauncher = AppLauncher(context)
    private val phoneCallManager = PhoneCallManager(context)
    private val localStorage = LocalStorage(context)
    private val commandRouter = CommandRouter()
    private val deviceCapabilities = DeviceCapabilityManager(context)

    private val reminderHandler = ReminderCommandHandler(
        ReminderManager(context)
    )

    fun execute(input: String): CommandExecutionResult {

        if (input.isBlank()) {
            return CommandExecutionResult(
                false,
                "Please tell me what you want me to do."
            )
        }

        val normalized = input.trim().lowercase(Locale.ROOT)
        val navigationAction = when (normalized) {
            "go back", "back", "वापस जाओ" -> "back"
            "go home", "open home screen", "home screen", "होम स्क्रीन" -> "home"
            "show recent apps", "open recent apps", "recent apps" -> "recents"
            "show notifications", "open notifications", "notifications" -> "notifications"
            "open quick settings", "show quick settings", "quick settings" -> "quick_settings"
            "show power menu", "open power menu" -> "power_dialog"
            else -> null
        }
        if (navigationAction != null) {
            val success = JarvisAccessibilityService.performNavigation(navigationAction)
            return CommandExecutionResult(
                success,
                if (success) "Done." else "Please enable JARVIS navigation controls in Android Accessibility settings first."
            )
        }

        // A second, explicit user command is required before Accessibility may tap Send.
        if (normalized == "confirm send" || normalized == "confirm message") {
            val sent = JarvisAccessibilityService.confirmSend()
            return CommandExecutionResult(true, if (sent) "The send button was activated. Please verify delivery in the messaging app." else "I could not verify a prepared message and active chat, so I did not send anything. Check the recipient and message, then try again.")
        }
        if (normalized == "cancel send" || normalized == "cancel message") {
            JarvisAccessibilityService.cancelPendingMessage()
            return CommandExecutionResult(true, "Pending message cancelled. Nothing will be sent.")
        }

        // External actions always open Android/app-owned screens for the user to review.
        val lower = input.trim().lowercase(Locale.ROOT)
        fun external(ok: Boolean, label: String) = CommandExecutionResult(ok,
            if (ok) label else "I couldn't open that screen. Please check the installed app and try again.")
        when {
            lower.startsWith("search web for ") || lower.startsWith("search for ") -> {
                val q = input.substringAfter(" for ", "").trim()
                return external(q.isNotBlank() && deviceCapabilities.searchWeb(q), "Opening web search for $q.")
            }
            lower.startsWith("navigate to ") || lower.startsWith("take me to ") -> {
                val place = input.substringAfter(" to ", "").trim()
                return external(place.isNotBlank() && deviceCapabilities.navigate(place), "Opening navigation to $place. Review the route before starting.")
            }
            lower.startsWith("find ") && (lower.contains(" on map") || lower.contains(" on maps")) -> {
                val place = input.substringAfter("find ").substringBeforeLast(" on map").substringBeforeLast(" on maps").trim()
                return external(place.isNotBlank() && deviceCapabilities.openMap(place), "Opening map results for $place.")
            }
            lower.startsWith("send sms to ") -> {
                val rest = input.substringAfter("send sms to ")
                val number = rest.substringBefore(" saying ").trim()
                val body = rest.substringAfter(" saying ", "").trim()
                return external(number.isNotBlank() && body.isNotBlank() && deviceCapabilities.composeSms(number, body), "SMS draft opened. Review the recipient and press Send yourself.")
            }
            lower.startsWith("send whatsapp to ") -> {
                val match = Regex("^send whatsapp to (.+?) saying (.+)$", RegexOption.IGNORE_CASE).find(input.trim())
                val recipient = match?.groupValues?.getOrNull(1).orEmpty().trim()
                val body = match?.groupValues?.getOrNull(2).orEmpty().trim()
                if (recipient.isBlank() || body.isBlank()) return CommandExecutionResult(false, "Use: send WhatsApp to +countrycode number saying your message.")
                if (!JarvisAccessibilityService.stageMessage("com.whatsapp", recipient, body)) return CommandExecutionResult(false, "Enable JARVIS Accessibility in Android settings first. No message was sent.")
                val opened = deviceCapabilities.prepareWhatsAppTo(recipient, body)
                if (!opened) JarvisAccessibilityService.cancelPendingMessage()
                return CommandExecutionResult(opened, if (opened) "WhatsApp chat opened and the message will be filled if supported. Check the recipient and message, then wait for JARVIS to read the recipient and message, then say JARVIS CONFIRM SEND or JARVIS CANCEL. The message will not send automatically." else "Could not open WhatsApp. Nothing was sent.")
            }
            lower.startsWith("send telegram to ") -> {
                val match = Regex("^send telegram to (.+?) saying (.+)$", RegexOption.IGNORE_CASE).find(input.trim())
                val recipient = match?.groupValues?.getOrNull(1).orEmpty().trim()
                val body = match?.groupValues?.getOrNull(2).orEmpty().trim()
                if (recipient.isBlank() || body.isBlank()) return CommandExecutionResult(false, "Use: send Telegram to @username saying your message.")
                if (!JarvisAccessibilityService.stageMessage("org.telegram.messenger", recipient, body)) return CommandExecutionResult(false, "Enable JARVIS Accessibility in Android settings first. No message was sent.")
                val opened = deviceCapabilities.prepareTelegramTo(recipient, body)
                if (!opened) JarvisAccessibilityService.cancelPendingMessage()
                return CommandExecutionResult(opened, if (opened) "Telegram chat opened and the message will be filled if supported. Check the recipient and message, then wait for JARVIS to read the recipient and message, then say JARVIS CONFIRM SEND or JARVIS CANCEL. The message will not send automatically." else "Could not open Telegram. Nothing was sent.")
            }
            lower.startsWith("share on whatsapp ") -> {
                val body = input.substringAfter("share on whatsapp ").trim()
                return external(body.isNotBlank() && deviceCapabilities.shareMessage("whatsapp", body), "WhatsApp share screen opened. Choose the recipient and send manually.")
            }
            lower.startsWith("share on telegram ") -> {
                val body = input.substringAfter("share on telegram ").trim()
                return external(body.isNotBlank() && deviceCapabilities.shareMessage("telegram", body), "Telegram share screen opened. Choose the recipient and send manually.")
            }
            lower.startsWith("share message ") -> {
                val body = input.substringAfter("share message ").trim()
                return external(body.isNotBlank() && deviceCapabilities.shareMessage("share", body), "Share sheet opened. Select an app and recipient; sending remains manual.")
            }
            lower.startsWith("email ") -> {
                val rest = input.substringAfter("email ")
                val address = rest.substringBefore(" subject ").trim()
                val subject = rest.substringAfter(" subject ", "").substringBefore(" body ").trim()
                val body = rest.substringAfter(" body ", "").trim()
                return external(address.contains("@") && deviceCapabilities.composeEmail(address, subject, body), "Email draft opened. Review it and press Send yourself.")
            }
            lower.startsWith("create calendar event ") -> {
                val title = input.substringAfter("create calendar event ").trim()
                return external(title.isNotBlank() && deviceCapabilities.createCalendarEvent(title, "Created with JARVIS"), "Calendar event form opened. Review date and time before saving.")
            }
            lower.startsWith("open wifi settings") -> return external(deviceCapabilities.openSettings("wifi"), "Opening Wi-Fi settings.")
            lower.startsWith("open internet settings") -> return external(deviceCapabilities.openSettings("internet"), "Opening internet settings.")
            lower.startsWith("open volume settings") -> return external(deviceCapabilities.openSettings("volume"), "Opening volume settings.")
        }

        val command = commandRouter.process(input)

        return when (command.type) {

            CommandType.GREETING -> CommandExecutionResult(
                true,
                "Hello! JARVIS is ready. How can I help you?"
            )

            CommandType.GET_TIME -> {
                val time = SimpleDateFormat(
                    "hh:mm a",
                    Locale.getDefault()
                ).format(Date())

                CommandExecutionResult(
                    true,
                    "The current time is $time."
                )
            }

            CommandType.GET_DATE -> {
                val date = SimpleDateFormat(
                    "EEEE, dd MMMM yyyy",
                    Locale.getDefault()
                ).format(Date())

                CommandExecutionResult(
                    true,
                    "Today is $date."
                )
            }

            CommandType.OPEN_APP -> {
                val result = appLauncher.launchApp(
                    command.argument.orEmpty()
                )

                CommandExecutionResult(
                    success = result.success,
                    response = result.message
                )
            }

            CommandType.SAVE_NOTE -> {
                val note = command.argument.orEmpty()

                if (note.isBlank()) {
                    CommandExecutionResult(
                        false,
                        "Please tell me what note to save."
                    )
                } else {
                    localStorage.saveNote(
                        "note_${System.currentTimeMillis()}",
                        note
                    )

                    CommandExecutionResult(
                        true,
                        "Your note has been saved."
                    )
                }
            }

            CommandType.CALL_CONTACT -> {
                val success = phoneCallManager.callContact(
                    command.argument.orEmpty()
                )

                CommandExecutionResult(
                    success = success,
                    response = if (success) {
                        "Opening the dialer. Please review and confirm the call."
                    } else {
                        "I couldn't find the contact or open the dialer. Please check the contact name and contact permission."
                    }
                )
            }

            CommandType.SET_REMINDER -> {
                reminderHandler.createReminder(input)
            }

            else -> CommandExecutionResult(
                false,
                "This command needs additional integration."
            )
        }
    }
}
