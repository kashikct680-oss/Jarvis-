package com.kishore.jarvis.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat

/**
 * User-started foreground wake phrase listener. Android's speech provider may use
 * network recognition; this is not an always-on DSP/offline hotword engine.
 */
class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var stopping = false
    private val channelId = "jarvis_wake_word"

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopping = true
            releaseRecognizer()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        stopping = false
        startForeground(NOTIFICATION_ID, buildNotification())
        beginListening()
        return START_STICKY
    }

    private fun beginListening() {
        if (stopping || !SpeechRecognizer.isRecognitionAvailable(this)) return
        releaseRecognizer()
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { speech ->
                speech.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onError(error: Int) { restartSoon() }
                    override fun onResults(results: Bundle?) {
                        val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull().orEmpty().trim()
                        val normalized = phrase.lowercase()
                        val wakeIndex = normalized.indexOf("hey jarvis")
                        if (wakeIndex >= 0) {
                            val command = phrase.substring(wakeIndex + "hey jarvis".length).trim()
                            if (command.isNotBlank()) {
                                sendBroadcast(Intent(ACTION_COMMAND).setPackage(packageName).putExtra(EXTRA_COMMAND, command))
                            } else {
                                sendBroadcast(Intent(ACTION_WAKE).setPackage(packageName))
                            }
                        }
                        restartSoon()
                    }
                })
                val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                speech.startListening(speechIntent)
            }
        } catch (_: Exception) { restartSoon() }
    }

    private fun restartSoon() {
        if (!stopping) {
            // SpeechRecognizer callbacks arrive on the main thread. A short post avoids
            // immediately restarting while the provider is still finalizing a session.
            android.os.Handler(mainLooper).postDelayed({ if (!stopping) beginListening() }, 900)
        }
    }

    private fun releaseRecognizer() {
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "JARVIS wake word", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification = NotificationCompat.Builder(this, channelId)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("JARVIS is listening")
        .setContentText("Say ‘Hey JARVIS’ followed by a command. Tap Stop in app to disable.")
        .setOngoing(true)
        .build()

    override fun onDestroy() { stopping = true; releaseRecognizer(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.kishore.jarvis.WAKE_START"
        const val ACTION_STOP = "com.kishore.jarvis.WAKE_STOP"
        const val ACTION_COMMAND = "com.kishore.jarvis.WAKE_COMMAND"
        const val ACTION_WAKE = "com.kishore.jarvis.WAKE_ONLY"
        const val EXTRA_COMMAND = "command"
        private const val CHANNEL_ID = "jarvis_wake_word"
        private const val NOTIFICATION_ID = 701
    }
}
