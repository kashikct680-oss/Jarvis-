package com.kishore.jarvis.automation

import android.content.Context
import android.content.Intent
import android.os.Build
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import java.util.Locale

/** Opens Android-owned, user-reviewable flows. JARVIS never silently sends, pays, books, or changes protected settings. */
class DeviceCapabilityManager(private val context: Context) {
    private fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (_: Exception) { false }

    fun searchWeb(query: String): Boolean = launch(Intent(Intent.ACTION_VIEW,
        Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")))

    fun navigate(destination: String): Boolean = launch(Intent(Intent.ACTION_VIEW,
        Uri.parse("google.navigation:q=${Uri.encode(destination)}")))

    fun openMap(place: String): Boolean = launch(Intent(Intent.ACTION_VIEW,
        Uri.parse("geo:0,0?q=${Uri.encode(place)}")))

    fun composeSms(number: String, body: String): Boolean = launch(Intent(Intent.ACTION_SENDTO,
        Uri.parse("smsto:${Uri.encode(number)}")).putExtra("sms_body", body))

    fun shareMessage(app: String, message: String): Boolean {
        val encoded = Uri.encode(message)
        val intent = when (app.lowercase(Locale.ROOT)) {
            "whatsapp" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=$encoded"))
            "telegram" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/share/url?url=&text=$encoded"))
            else -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, message)
        }
        return launch(intent)
    }


    fun prepareWhatsAppTo(phone: String, message: String): Boolean {
        if (phone.isBlank() || message.isBlank()) return false
        val number = phone.filter { it.isDigit() }
        if (number.length < 7) return false
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number?text=${Uri.encode(message)}"))
            .setPackage("com.whatsapp")
        return launch(intent)
    }

    fun prepareTelegramTo(username: String, message: String): Boolean {
        if (username.isBlank() || message.isBlank()) return false
        val clean = username.removePrefix("@").filter { it.isLetterOrDigit() || it == '_' }
        if (clean.isBlank()) return false
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=$clean&text=${Uri.encode(message)}"))
            .setPackage("org.telegram.messenger")
        return launch(intent)
    }

    fun composeEmail(address: String, subject: String, body: String): Boolean = launch(
        Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${Uri.encode(address)}"))
            .putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, body)
    )

    fun createCalendarEvent(title: String, details: String): Boolean = launch(
        Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.Events.DESCRIPTION, details)
    )

    fun setAlarm(hour: Int, minute: Int, label: String): Boolean = launch(
        Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
    )

    fun openSettings(section: String): Boolean {
        val action = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (section.lowercase(Locale.ROOT)) {
                "wifi" -> Settings.Panel.ACTION_WIFI
                "internet", "network" -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                "volume", "sound" -> Settings.Panel.ACTION_VOLUME
                "nfc" -> Settings.Panel.ACTION_NFC
                else -> Settings.ACTION_SETTINGS
            }
        } else {
            when (section.lowercase(Locale.ROOT)) {
                "wifi", "internet", "network" -> Settings.ACTION_WIFI_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
        }
        return launch(Intent(action))
    }
}
