package com.kishore.jarvis.automation

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.Locale

/** Optional user-enabled service. It fills drafts; sending requires a separate voice approval. */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val request = pendingMessage ?: return
        if (SystemClock.elapsedRealtime() > request.expiresAt) {
            cancelPendingMessage()
            return
        }
        val pkg = event?.packageName?.toString() ?: return
        if (pkg != request.packageName || request.filled) return
        val root = rootInActiveWindow ?: return
        val editor = findEditable(root)
        if (editor != null) {
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, request.body)
            }
            request.filled = editor.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            editor.recycle()
            if (request.filled) {
                request.expiresAt = SystemClock.elapsedRealtime() + 30_000L
                serviceNotification()
                sendBroadcast(Intent(ACTION_READY_TO_CONFIRM).setPackage(packageName).apply {
                    putExtra(EXTRA_PLATFORM, request.platformLabel)
                    putExtra(EXTRA_RECIPIENT, request.recipient)
                    putExtra(EXTRA_BODY, request.body)
                })
            }
        }
        root.recycle()
    }

    override fun onInterrupt() = Unit
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    private fun serviceNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "JARVIS message approval", NotificationManager.IMPORTANCE_HIGH)
        )
        val cancelIntent = Intent(this, MessagingActionReceiver::class.java).setAction(MessagingActionReceiver.ACTION_CANCEL)
        val cancelPending = PendingIntent.getBroadcast(this, 8102, cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("JARVIS is waiting for voice approval")
            .setContentText("Listen to the recipient and message, then approve by voice. Nothing has been sent.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Say 'Jarvis, confirm send' only after JARVIS reads the full recipient and message, or say 'Jarvis, cancel'."))
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelPending)
            .build()
        try { manager.notify(NOTIFICATION_ID, notification) } catch (_: SecurityException) { }
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isEnabled) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditable(child)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    companion object {
        private data class PendingMessage(
            val packageName: String,
            val platformLabel: String,
            val recipient: String,
            val body: String,
            var expiresAt: Long,
            var filled: Boolean = false
        )
        const val ACTION_READY_TO_CONFIRM = "com.kishore.jarvis.action.MESSAGE_READY_FOR_VOICE_APPROVAL"
        const val EXTRA_PLATFORM = "platform"
        const val EXTRA_RECIPIENT = "recipient"
        const val EXTRA_BODY = "body"
        private const val CHANNEL_ID = "jarvis_message_confirmation"
        private const val NOTIFICATION_ID = 8120
        @Volatile private var instance: JarvisAccessibilityService? = null
        @Volatile private var pendingMessage: PendingMessage? = null

        fun isEnabled(): Boolean = instance != null

        fun stageMessage(packageName: String, recipient: String, body: String): Boolean {
            if (instance == null || recipient.isBlank() || body.isBlank()) return false
            if (packageName != "com.whatsapp" && packageName != "org.telegram.messenger") return false
            val label = if (packageName == "com.whatsapp") "WhatsApp" else "Telegram"
            pendingMessage = PendingMessage(packageName, label, recipient, body,
                SystemClock.elapsedRealtime() + 30_000L)
            return true
        }

        fun pendingVoicePrompt(): String? {
            val request = pendingMessage ?: return null
            if (SystemClock.elapsedRealtime() > request.expiresAt || !request.filled) return null
            return "You are about to send a ${request.platformLabel} message to ${request.recipient}. The message says: ${request.body}. Do you approve? Say Jarvis, confirm send, or Jarvis, cancel."
        }

        fun cancelPendingMessage() {
            pendingMessage = null
            instance?.getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
        }

        /** Called only after the user says the exact confirmation phrase. */
        fun confirmSend(): Boolean {
            val service = instance ?: return false
            val request = pendingMessage ?: return false
            if (SystemClock.elapsedRealtime() > request.expiresAt || !request.filled) {
                cancelPendingMessage(); return false
            }
            val root = service.rootInActiveWindow ?: return false
            if (root.packageName?.toString() != request.packageName) { root.recycle(); return false }
            val sendNode = findSendNode(root)
            val clicked = sendNode?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            sendNode?.recycle(); root.recycle()
            if (clicked) cancelPendingMessage()
            return clicked
        }

        private fun findSendNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
                .joinToString(" ").lowercase(Locale.ROOT).trim()
            if ((label == "send" || label == "send message") && node.isEnabled && node.isClickable)
                return AccessibilityNodeInfo.obtain(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val found = findSendNode(child); child.recycle()
                if (found != null) return found
            }
            return null
        }

        fun performNavigation(action: String): Boolean {
            val service = instance ?: return false
            val globalAction = when (action.lowercase()) {
                "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                "power_dialog" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
                else -> return false
            }
            return service.performGlobalAction(globalAction)
        }
    }
}
