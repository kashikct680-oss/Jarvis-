/**
 * JARVIS Cloudflare Worker proxy.
 * Configure secrets GEMINI_API_KEY and JARVIS_ACCESS_TOKEN in Cloudflare.
 * Never put either secret in this repository or Android app source.
 */
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json; charset=utf-8"
};
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: cors });

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (request.method === "GET") return json({ status: "JARVIS backend online" });
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);
    if (!env.GEMINI_API_KEY || !env.JARVIS_ACCESS_TOKEN) return json({ error: "Backend secrets are not configured" }, 503);

    const authorization = request.headers.get("Authorization") || "";
    const suppliedToken = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
    if (suppliedToken.length !== env.JARVIS_ACCESS_TOKEN.length || suppliedToken !== env.JARVIS_ACCESS_TOKEN) {
      return json({ error: "Unauthorized. Check the JARVIS access token." }, 401);
    }

    const declaredLength = Number(request.headers.get("Content-Length") || 0);
    if (declaredLength > 30000) return json({ error: "Request is too large" }, 413);

    try {
      const body = await request.json();
      if (!Array.isArray(body.messages) || body.messages.length === 0) return json({ error: "No messages provided" }, 400);
      const contents = body.messages.slice(-16).map((m) => ({
        role: m.role === "assistant" || m.role === "model" ? "model" : "user",
        parts: [{ text: String(m.content || "").slice(0, 6000) }]
      }));
      const apiResponse = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: "You are JARVIS, a helpful personal assistant. Understand English, Hindi and Hinglish. Be concise and practical. Never claim to have sent a message, placed a call, booked, purchased, paid, or changed a device setting unless the app has actually confirmed it. Ask the user to review sensitive actions. If asked for current information, use Google Search grounding when available and clearly distinguish verified facts from uncertainty." }] },
          contents,
          tools: [{ google_search: {} }],
          generationConfig: { temperature: 0.65, maxOutputTokens: 1200 }
        })
      });
      const result = await apiResponse.json();
      if (!apiResponse.ok) return json({ error: result.error?.message || "Gemini request failed" }, 502);
      const text = (result.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("").trim();
      if (!text) return json({ error: "Gemini returned an empty response" }, 502);
      return json({ text });
    } catch (error) {
      return json({ error: error?.message || "Backend processing failed" }, 500);
    }
  }
};
