# JARVIS Advanced Edition — Android project

This is a Kotlin + Jetpack Compose Android assistant project for Android 8.0+ (API 26+). It is designed to be built in GitHub Actions; Android Studio/local builds are not required.

## Included in this update

- Hologram-style Compose interface and text conversation.
- Tap-to-talk speech recognition with English (India) / Hindi (India) language toggle, plus text-to-speech response (Hindi script is spoken using Hindi TTS when available).
- Local commands: greeting, time/date, opening installed apps, notes, reminders, browser search, maps navigation and Android Settings.
- Contact lookup and dialer hand-off (JARVIS opens the dialer; the user presses Call).
- Messaging share sheet / SMS or WhatsApp preparation modules. JARVIS does not silently send messages.
- Reminder notifications, exact-alarm permission checks, and reminder restoration after reboot/app update.
- Optional notification access service. It stores recent notification text locally only after the user enables Notification Access in Android Settings.
- Gemini backend client and Cloudflare Worker source. Gemini API key and Worker access token are server-side secrets; the app stores only the backend URL and Worker access token in its private app preferences.
- GitHub Actions workflow to build and upload a debug APK artifact.

## Important limitations (not silently automated)

This project is a practical assistant foundation, not unrestricted control of Android or every third-party app. Android and app-provider security boundaries still apply:

- **Wake word / always-on “Hey JARVIS”:** not implemented in this release. Reliable always-on wake-word detection needs an on-device wake-word model, microphone foreground service, persistent notification, and Xiaomi battery/background configuration. Continuous cloud speech recognition is not used because it would create privacy and battery concerns.
- **Incoming-call answer/reject/end:** not implemented. It requires a dedicated call-screening/default-dialer implementation and user-granted role; this app does not silently control calls.
- **Bookings, purchases and payments:** JARVIS can open apps, web search, maps and prepare workflows, but final actions must be reviewed and completed by the user. Many apps prohibit or do not expose third-party automation APIs.
- **Messages:** Android opens the appropriate share/compose interface. The user selects recipient and presses Send. Direct silent sending is not supported.
- **Device controls:** protected settings cannot be changed silently. JARVIS can open Android Settings for the user.
- **SAP/JSA:** no company SAP connection is included. A company-approved SAP API, credentials, and security review are required before integration.
- **Offline AI:** local commands work without the Gemini backend. Complex AI conversation and search grounding require internet and a configured Gemini backend. Gemini free-tier availability/limits depend on Google's current account and region policies.

## Configure Gemini backend (required for online AI)

1. Create a Cloudflare account and create a Worker.
2. Deploy `backend/worker.js` as the Worker entry point. `backend/wrangler.toml` is included for Wrangler deployments.
3. Create a Gemini API key in Google AI Studio.
4. In Cloudflare Worker settings, add these **Secrets** (not plain-text variables):
   - `GEMINI_API_KEY` — your Google AI Studio API key.
   - `JARVIS_ACCESS_TOKEN` — a long random token that you generate and keep private.
5. Deploy the Worker. Its URL looks like `https://your-worker-name.your-account.workers.dev`.
6. Open JARVIS → **SETTINGS** and enter the Worker URL and the same `JARVIS_ACCESS_TOKEN` value. Tap Save.
7. Test with a normal question. The Worker uses Gemini 2.5 Flash and requests Google Search grounding for current-information questions where supported.

Never commit the Gemini API key or access token to GitHub. If either is accidentally exposed, rotate it immediately.

## Android permissions and first-run setup

- Microphone: requested when the MIC button is tapped.
- Contacts: requested when a contact-call command is used.
- Notifications: requested on first launch (Android 13+); required for reminder alerts.
- Exact alarms: on Android 12+, open Android Settings → Apps → Special app access → Alarms & reminders → JARVIS and allow it. Exact-alarm access is controlled by Android.
- Notification reading: ask JARVIS “read notifications”; enable JARVIS under Android Settings → Notification access. Only new notifications after access is enabled are captured.
- Xiaomi/HyperOS may restrict background activity. This release does not claim always-on background listening.

## Example commands

- `Open YouTube`
- `What time is it?`
- `Save note: buy a notebook`
- `Remind me to call Rahul at 6 PM`
- `Remind me to study tomorrow at 9 AM`
- `Remind me to stretch in 30 minutes`
- `Search the web for NTPC recruitment update`
- `Navigate to Raipur railway station`
- `Call Rahul` (opens dialer; user confirms call)
- `Read notifications` (requires Notification Access)
- `Open Swiggy and find restaurants` (opens the app if installed; the app workflow remains user-controlled)

## Build APK with GitHub Actions

The workflow `.github/workflows/android.yml` runs on every push to `main` and on manual dispatch. After uploading these project files to the repository:

1. Open the repository → Actions.
2. Open the latest **Build JARVIS APK** run.
3. Wait for the green check.
4. Download the `JARVIS-APK` artifact. Extract it to get `app-debug.apk`.
5. Transfer the APK to the Android phone and install it. Android may ask you to allow installation from that browser/file manager.

A successful ZIP upload or source edit is not proof of a successful APK build. Check the Actions run before installing. This source bundle has not been compiled in this environment; GitHub Actions is the authoritative build check.
