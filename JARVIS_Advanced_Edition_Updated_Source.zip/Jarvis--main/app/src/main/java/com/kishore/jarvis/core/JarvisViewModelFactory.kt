package com.kishore.jarvis.core

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.kishore.jarvis.ai.AiRepository
import com.kishore.jarvis.ai.BackendSettings
import com.kishore.jarvis.ai.GeminiService
import com.kishore.jarvis.automation.CommandExecutionManager
import com.kishore.jarvis.memory.LocalStorage

class JarvisViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (!modelClass.isAssignableFrom(JarvisViewModel::class.java)) {
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
        val appContext = context.applicationContext
        val aiRepository: AiRepository = GeminiService(BackendSettings(appContext))
        return JarvisViewModel(
            aiRepository,
            LocalStorage(appContext),
            CommandExecutionManager(appContext)
        ) as T
    }
}
