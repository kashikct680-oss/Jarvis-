package com.kishore.jarvis.ai

import android.content.Context

/** Keeps the backend endpoint and access token on this device, not in source control. */
class BackendSettings(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences("jarvis_backend", Context.MODE_PRIVATE)

    fun url(): String = preferences.getString("url", "")?.trim().orEmpty()
    fun token(): String = preferences.getString("token", "")?.trim().orEmpty()

    fun save(url: String, token: String) {
        preferences.edit().putString("url", url.trim()).putString("token", token.trim()).apply()
    }
}
