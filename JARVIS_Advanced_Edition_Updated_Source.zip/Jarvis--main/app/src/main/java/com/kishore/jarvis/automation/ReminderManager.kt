package com.kishore.jarvis.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.UUID

 data class JarvisReminder(val id: String, val title: String, val triggerAtMillis: Long)

class ReminderManager(private val context: Context) {
    private val preferences = context.getSharedPreferences("jarvis_reminders", Context.MODE_PRIVATE)

    fun scheduleReminder(title: String, triggerAtMillis: Long): Result<JarvisReminder> {
        if (title.isBlank()) return Result.failure(IllegalArgumentException("Reminder title cannot be empty."))
        if (triggerAtMillis <= System.currentTimeMillis()) return Result.failure(IllegalArgumentException("Please choose a future time."))
        return try {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
                return Result.failure(IllegalStateException("Allow JARVIS to schedule exact alarms in Android Settings, then try again."))
            }
            val reminder = JarvisReminder(UUID.randomUUID().toString(), title.trim(), triggerAtMillis)
            scheduleExisting(reminder)
            preferences.edit().putString(reminder.id, "${reminder.triggerAtMillis}\n${reminder.title}").apply()
            Result.success(reminder)
        } catch (e: Exception) { Result.failure(e) }
    }

    private fun scheduleExisting(reminder: JarvisReminder) {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACTION_REMINDER
            putExtra("reminder_id", reminder.id)
            putExtra("reminder_title", reminder.title)
        }
        val pending = PendingIntent.getBroadcast(context, reminder.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAtMillis, pending)
    }

    fun cancelReminder(id: String): Boolean {
        return try {
            val intent = Intent(context, ReminderReceiver::class.java).apply { action = ACTION_REMINDER }
            val pending = PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return false
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
            pending.cancel()
            preferences.edit().remove(id).apply()
            true
        } catch (_: Exception) { false }
    }

    fun restoreReminders() {
        val now = System.currentTimeMillis()
        preferences.all.forEach { (id, raw) ->
            val value = raw as? String ?: return@forEach
            val parts = value.split("\n", limit = 2)
            val time = parts.firstOrNull()?.toLongOrNull() ?: return@forEach
            val title = parts.getOrNull(1).orEmpty()
            if (time > now && title.isNotBlank()) {
                runCatching { scheduleExisting(JarvisReminder(id, title, time)) }
            } else preferences.edit().remove(id).apply()
        }
    }

    companion object { const val ACTION_REMINDER = "com.kishore.jarvis.REMINDER" }
}
