package com.kishore.jarvis.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Calls the user's private Cloudflare Worker. No Gemini key is stored in the APK. */
class GeminiService(private val settings: BackendSettings) : AiRepository {
    override suspend fun ask(userMessage: String, conversationHistory: List<ChatMessage>): AiResponse = withContext(Dispatchers.IO) {
        if (userMessage.isBlank()) return@withContext AiResponse(false, "", "Please enter a message.")
        val endpoint = settings.url()
        if (endpoint.isBlank() || endpoint.contains("YOUR-", ignoreCase = true)) {
            return@withContext AiResponse(false, "", "AI is not configured yet. Open JARVIS settings and enter your deployed backend URL and access token.")
        }
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer ${settings.token()}")
            }
            val messages = JSONArray()
            conversationHistory.takeLast(16).forEach { item ->
                messages.put(JSONObject().put("role", item.role).put("content", item.content))
            }
            messages.put(JSONObject().put("role", "user").put("content", userMessage))
            connection.outputStream.use { it.write(JSONObject().put("messages", messages).toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(body).optString("error", "") }.getOrDefault("")
                return@withContext AiResponse(false, "", "AI server error ($code). ${detail.ifBlank { "Check backend URL and access token." }}")
            }
            val answer = JSONObject(body).optString("text", "").trim()
            if (answer.isBlank()) AiResponse(false, "", "The AI returned an empty response.") else AiResponse(true, answer)
        } catch (e: Exception) {
            AiResponse(false, "", e.message ?: "Unable to connect to the AI service.")
        } finally {
            connection?.disconnect()
        }
    }

    override suspend fun isAvailable(): Boolean = withContext(Dispatchers.IO) {
        val endpoint = settings.url()
        if (endpoint.isBlank()) return@withContext false
        runCatching {
            val c = URL(endpoint).openConnection() as HttpURLConnection
            c.requestMethod = "GET"
            c.connectTimeout = 5000
            c.readTimeout = 5000
            val ok = c.responseCode in 200..499
            c.disconnect()
            ok
        }.getOrDefault(false)
    }
}
