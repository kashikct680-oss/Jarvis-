package com.kishore.jarvis.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.kishore.jarvis.core.JarvisState

@Composable
fun JarvisScreen(
    state: JarvisState,
    voiceLanguageLabel: String,
    backendUrl: String,
    backendToken: String,
    onSendMessage: (String) -> Unit,
    onMicrophoneClick: () -> Unit,
    onLanguageToggle: () -> Unit,
    onOpenSettings: () -> Unit,
    onSaveBackendSettings: (String, String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var urlInput by remember(backendUrl) { mutableStateOf(backendUrl) }
    var tokenInput by remember(backendToken) { mutableStateOf(backendToken) }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF050B14)).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("J.A.R.V.I.S", color = Color.Cyan, style = MaterialTheme.typography.headlineMedium)
                Text(state.statusMessage, color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)
            }
            TextButton(onClick = { showSettings = true; onOpenSettings() }) { Text("SETTINGS") }
        }
        Spacer(Modifier.height(8.dp))
        HologramCore(isListening = state.isListening, isProcessing = state.isProcessing, isSpeaking = state.isSpeaking)
        ConversationPanel(messages = state.conversation, modifier = Modifier.weight(1f))
        state.errorMessage?.let { Text(it, color = Color(0xFFFF9999), modifier = Modifier.padding(vertical = 8.dp)) }
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ask JARVIS anything...") },
            shape = RoundedCornerShape(14.dp),
            minLines = 1,
            maxLines = 4
        )
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onMicrophoneClick, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087EAA))) { Text("MIC") }
            Button(onClick = onLanguageToggle, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF31536A))) { Text(voiceLanguageLabel) }
            Button(
                onClick = { val message = input.trim(); if (message.isNotEmpty()) { onSendMessage(message); input = "" } },
                modifier = Modifier.weight(1f), enabled = input.isNotBlank() && !state.isProcessing
            ) { Text("SEND") }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("AI backend settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter your deployed Worker URL and the access token you configured as a Worker secret. These values are stored only on this phone.")
                    OutlinedTextField(value = urlInput, onValueChange = { urlInput = it }, label = { Text("Backend URL") }, singleLine = true)
                    OutlinedTextField(value = tokenInput, onValueChange = { tokenInput = it }, label = { Text("Access token") }, singleLine = true)
                }
            },
            confirmButton = { TextButton(onClick = { onSaveBackendSettings(urlInput, tokenInput); showSettings = false }) { Text("SAVE") } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("CANCEL") } }
        )
    }
}
