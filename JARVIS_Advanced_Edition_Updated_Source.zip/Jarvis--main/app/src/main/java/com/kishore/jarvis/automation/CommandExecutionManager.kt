package com.kishore.jarvis.automation

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.kishore.jarvis.core.CommandRouter
import com.kishore.jarvis.core.CommandType
import com.kishore.jarvis.memory.LocalStorage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CommandExecutionResult(
    val success: Boolean,
    val response: String,
    val requiresConfirmation: Boolean = false,
    /** False means the request should be passed to the online AI. */
    val handled: Boolean = true
)

class CommandExecutionManager(private val context: Context) {
    private val appLauncher = AppLauncher(context)
    private val phoneCallManager = PhoneCallManager(context)
    private val messagingManager = MessagingManager(context)
    private val appIntegrationManager = AppIntegrationManager(context)
    private val localStorage = LocalStorage(context)
    private val commandRouter = CommandRouter()
    private val reminderHandler = ReminderCommandHandler(ReminderManager(context))

    fun execute(input: String): CommandExecutionResult {
        if (input.isBlank()) return CommandExecutionResult(false, "Please tell me what you want me to do.")
        val command = commandRouter.process(input)
        return when (command.type) {
            CommandType.GREETING -> ok("Hello! JARVIS is ready. How can I help you?")
            CommandType.GET_TIME -> ok("The current time is ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())}.")
            CommandType.GET_DATE -> ok("Today is ${SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())}.")
            CommandType.OPEN_APP -> {
                val name = command.argument.ifBlank { command.appName }
                val result = appLauncher.launchApp(name)
                CommandExecutionResult(result.success, result.message)
            }
            CommandType.APP_TASK -> {
                val appName = command.appName
                if (appName.isBlank()) CommandExecutionResult(false, "Tell me which app to open, for example: Open Swiggy and find restaurants.")
                else {
                    val result = appIntegrationManager.executeRequest(appName, command.taskDescription)
                    CommandExecutionResult(result.appOpened, result.message)
                }
            }
            CommandType.SET_REMINDER -> reminderHandler.createReminder(input)
            CommandType.SAVE_NOTE -> {
                val note = input.replace(Regex("(?i)^(please\\s+)?(save note|take a note|make a note|remember this)\\s*[:,-]?\\s*"), "")
                    .replace(Regex("^(याद रखना|नोट बनाओ|नोट सेव करो)\\s*[:,-]?\\s*"), "").trim()
                if (note.isBlank()) CommandExecutionResult(false, "Please tell me what I should save.")
                else {
                    localStorage.saveNote("note_${System.currentTimeMillis()}", note)
                    ok("Saved your note: $note")
                }
            }
            CommandType.CALL_CONTACT -> {
                val result = phoneCallManager.callContact(command.argument)
                CommandExecutionResult(result.success, result.message, requiresConfirmation = false)
            }
            CommandType.SEND_MESSAGE -> {
                val message = input.substringAfter(":", "").trim().ifBlank { input }
                val result = messagingManager.prepareShareMessage(message)
                CommandExecutionResult(result.success, result.message, requiresConfirmation = true)
            }
            CommandType.SEARCH_WEB -> {
                val query = command.argument.ifBlank { input }
                openUrl("https://www.google.com/search?q=${Uri.encode(query)}", "Opening web search for: $query")
            }
            CommandType.NAVIGATE -> {
                val destination = command.argument.ifBlank { input }
                openUrl("geo:0,0?q=${Uri.encode(destination)}", "Opening maps for $destination. Review the route before starting navigation.")
            }
            CommandType.OPEN_SETTINGS -> {
                try {
                    context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    ok("Opening Android Settings.")
                } catch (_: Exception) { CommandExecutionResult(false, "Unable to open Android Settings.") }
            }
            CommandType.READ_NOTIFICATIONS -> {
                if (JarvisNotificationListener.hasAccess(context)) ok(JarvisNotificationListener.recent(context))
                else {
                    try {
                        context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        ok("Please enable JARVIS Notification Access in the settings screen, then ask me to read notifications again.")
                    } catch (_: Exception) { CommandExecutionResult(false, "Open Android Settings and enable Notification Access for JARVIS.") }
                }
            }
            CommandType.CALL_LAST_NUMBER -> CommandExecutionResult(false, "For safety, use the Phone app's recent-calls list. JARVIS does not place calls without your review.")
            CommandType.ANSWER_CALL, CommandType.REJECT_CALL, CommandType.END_CALL -> CommandExecutionResult(false, "Call answering and rejecting require JARVIS to be configured as the default phone app with a dedicated call-screen service. This is not enabled in this build.")
            CommandType.UNKNOWN -> CommandExecutionResult(false, "", handled = false)
        }
    }

    private fun ok(message: String) = CommandExecutionResult(true, message)

    private fun openUrl(url: String, message: String): CommandExecutionResult = try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ok(message)
    } catch (_: Exception) {
        CommandExecutionResult(false, "No browser is available to open this search.")
    }
}
