package com.kishore.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.kishore.jarvis.ai.BackendSettings
import com.kishore.jarvis.core.JarvisViewModel
import com.kishore.jarvis.core.JarvisViewModelFactory
import com.kishore.jarvis.ui.JarvisScreen
import com.kishore.jarvis.voice.SpeechInputManager
import com.kishore.jarvis.voice.SpeechOutputManager

class MainActivity : ComponentActivity() {
    private lateinit var jarvisViewModel: JarvisViewModel
    private lateinit var speechOutput: SpeechOutputManager
    private lateinit var backendSettings: BackendSettings
    private var speechInput: SpeechInputManager? = null
    private var voiceLanguage by mutableStateOf("en-IN")
    private var pendingContactCommand: String? = null

    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoiceRecognition(voiceLanguage) else jarvisViewModel.setListening(false)
    }
    private val contactsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val command = pendingContactCommand
        pendingContactCommand = null
        if (granted && command != null) jarvisViewModel.processText(command)
        else if (!granted) Toast.makeText(this, "Contacts permission is required for contact lookup.", Toast.LENGTH_LONG).show()
    }
    private val notificationsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backendSettings = BackendSettings(applicationContext)
        jarvisViewModel = ViewModelProvider(this, JarvisViewModelFactory(applicationContext))[JarvisViewModel::class.java]
        speechOutput = SpeechOutputManager(this)
        speechInput = SpeechInputManager(
            context = this,
            onResult = { spoken -> runOnUiThread { jarvisViewModel.setListening(false); handleUserCommand(spoken) } },
            onError = { error -> runOnUiThread { jarvisViewModel.setListening(false); Toast.makeText(this, error, Toast.LENGTH_SHORT).show() } }
        )
        requestNotificationPermissionIfNeeded()

        setContent {
            MaterialTheme {
                val currentState = jarvisViewModel.state
                LaunchedEffect(currentState.response) {
                    if (currentState.response.isNotBlank()) {
                        val language = if (currentState.response.any { it in '\u0900'..'\u097F' }) "hi" else "en"
                        speechOutput.speak(currentState.response, language)
                    }
                }
                JarvisScreen(
                    state = currentState,
                    voiceLanguageLabel = if (voiceLanguage == "en-IN") "EN" else "HI",
                    backendUrl = backendSettings.url(),
                    backendToken = backendSettings.token(),
                    onSendMessage = { handleUserCommand(it) },
                    onMicrophoneClick = { requestMicrophonePermission() },
                    onLanguageToggle = {
                        voiceLanguage = if (voiceLanguage == "en-IN") "hi-IN" else "en-IN"
                        Toast.makeText(this, "Voice language: ${if (voiceLanguage == "en-IN") "English" else "Hindi"}", Toast.LENGTH_SHORT).show()
                    },
                    onOpenSettings = { },
                    onSaveBackendSettings = { url, token ->
                        backendSettings.save(url, token)
                        Toast.makeText(this, "Backend settings saved on this phone.", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }

    private fun handleUserCommand(command: String) {
        val lower = command.lowercase()
        val isContactCall = lower.startsWith("call ") || lower.startsWith("phone ") || lower.startsWith("dial ") ||
            lower.contains("को कॉल करो") || lower.contains("को फोन करो")
        if (isContactCall && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingContactCommand = command
            contactsPermission.launch(Manifest.permission.READ_CONTACTS)
        } else {
            jarvisViewModel.processText(command)
        }
    }

    private fun requestMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoiceRecognition(voiceLanguage)
        } else microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startVoiceRecognition(language: String) {
        if (speechInput?.isRecognitionAvailable() == true) {
            jarvisViewModel.setListening(true)
            speechInput?.startListening(language)
        } else {
            jarvisViewModel.setListening(false)
            Toast.makeText(this, "Speech recognition is unavailable. Install or enable a speech recognition service.", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationsPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onDestroy() {
        speechInput?.destroy()
        speechOutput.shutdown()
        super.onDestroy()
    }
}
