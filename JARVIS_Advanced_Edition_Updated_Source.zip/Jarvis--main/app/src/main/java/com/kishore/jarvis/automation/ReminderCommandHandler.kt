package com.kishore.jarvis.automation

import java.time.LocalTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class ReminderCommandHandler(private val reminderManager: ReminderManager) {
    fun createReminder(input: String): CommandExecutionResult {
        val text = input.trim().lowercase(Locale.ROOT)
        val now = ZonedDateTime.now()
        val trigger = parseTriggerTime(text, now)
            ?: return CommandExecutionResult(false, "Please specify a time, for example 6 PM, 18:30, tomorrow at 9 AM, or in 30 minutes.")
        val title = extractTitle(input)
        if (title.isBlank()) return CommandExecutionResult(false, "Please tell me what I should remind you about.")
        val result = reminderManager.scheduleReminder(title, trigger.toInstant().toEpochMilli())
        return result.fold(
            onSuccess = {
                val formatted = trigger.format(DateTimeFormatter.ofPattern("dd MMM, hh:mm a", Locale.getDefault()))
                CommandExecutionResult(true, "Reminder set: $title, at $formatted.")
            },
            onFailure = { CommandExecutionResult(false, it.message ?: "Unable to schedule reminder.") }
        )
    }

    private fun parseTriggerTime(text: String, now: ZonedDateTime): ZonedDateTime? {
        val relative = Regex("""(?:in|after)\s+(\d+)\s+(minutes?|mins?|hours?|hrs?)""").find(text)
        if (relative != null) {
            val amount = relative.groupValues[1].toLongOrNull() ?: return null
            return if (relative.groupValues[2].startsWith("min")) now.plusMinutes(amount) else now.plusHours(amount)
        }
        val hindiRelative = Regex("""(\d+)\s*(मिनट|मिनटों|घंटे|घंटा)\s*(बाद में|बाद)""").find(text)
        if (hindiRelative != null) {
            val amount = hindiRelative.groupValues[1].toLongOrNull() ?: return null
            return if (hindiRelative.groupValues[2].startsWith("मिनट")) now.plusMinutes(amount) else now.plusHours(amount)
        }

        val twelveHour = Regex("""(?:at\s*)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)""").find(text)
        val twentyFourHour = Regex("""(?:at\s*)?(\d{1,2}):(\d{2})""").find(text)
        val hindiHour = Regex("""(\d{1,2})\s*(?:baje|बजे)""").find(text)
        val hour: Int
        val minute: Int
        if (twelveHour != null) {
            val h = twelveHour.groupValues[1].toIntOrNull() ?: return null
            minute = twelveHour.groupValues[2].ifBlank { "0" }.toIntOrNull() ?: return null
            if (h !in 1..12 || minute !in 0..59) return null
            hour = when {
                twelveHour.groupValues[3] == "am" && h == 12 -> 0
                twelveHour.groupValues[3] == "pm" && h != 12 -> h + 12
                else -> h
            }
        } else if (twentyFourHour != null) {
            hour = twentyFourHour.groupValues[1].toIntOrNull() ?: return null
            minute = twentyFourHour.groupValues[2].toIntOrNull() ?: return null
            if (hour !in 0..23 || minute !in 0..59) return null
        } else if (hindiHour != null) {
            hour = hindiHour.groupValues[1].toIntOrNull() ?: return null
            minute = 0
            if (hour !in 0..23) return null
        } else return null

        val time = LocalTime.of(hour, minute)
        val dayOffset = when {
            text.contains("day after tomorrow") || text.contains("परसों") -> 2
            text.contains("tomorrow") || text.contains("कल") -> 1
            else -> 0
        }
        var result = ZonedDateTime.of(now.toLocalDate().plusDays(dayOffset.toLong()), time, now.zone)
        if (dayOffset == 0 && !result.isAfter(now)) result = result.plusDays(1)
        return result
    }

    private fun extractTitle(original: String): String {
        return original
            .replace(Regex("(?i)remind me to|remind me|set a reminder to|set reminder for|set a reminder for|create reminder|reminder to"), "")
            .replace(Regex("(?i)tomorrow|today|day after tomorrow|at\\s+\\d{1,2}(?::\\d{2})?\\s*(am|pm)|(?:at\\s*)?\\d{1,2}:\\d{2}|in\\s+\\d+\\s+(minutes?|mins?|hours?|hrs?)"), "")
            .replace(Regex("याद दिलाना|मुझे याद दिलाना|रिमाइंडर लगाओ|याद रखना|कल|परसों"), "")
            .replace(Regex("\\d+\\s*(मिनट|मिनटों|घंटे|घंटा)\\s*(बाद में|बाद)|\\d{1,2}\\s*(?:baje|बजे)"), "")
            .trim(' ', '.', ',', ':', '-')
    }
}
