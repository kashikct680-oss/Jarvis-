package com.kishore.jarvis.core

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kishore.jarvis.ai.AiRepository
import com.kishore.jarvis.ai.ChatMessage
import com.kishore.jarvis.automation.CommandExecutionManager
import com.kishore.jarvis.memory.LocalStorage
import kotlinx.coroutines.launch

class JarvisViewModel(
    private val aiRepository: AiRepository,
    private val localStorage: LocalStorage,
    private val commandExecutor: CommandExecutionManager
) : ViewModel() {
    var state by mutableStateOf(JarvisState())
        private set

    private val conversationHistory = mutableListOf<ChatMessage>()

    fun processText(input: String) {
        val text = input.trim()
        if (text.isBlank() || state.isProcessing) return
        state = state.copy(
            userInput = text,
            isProcessing = true,
            errorMessage = null,
            conversation = state.conversation + ConversationMessage(text, true),
            statusMessage = "JARVIS is processing..."
        )
        viewModelScope.launch {
            val local = runCatching { commandExecutor.execute(text) }.getOrNull()
            if (local != null && local.handled) {
                if (local.success) showAssistantResponse(local.response)
                else showError(local.response.ifBlank { "I couldn't complete that action." })
            } else {
                askAi(text)
            }
        }
    }

    private suspend fun askAi(input: String) {
        val response = aiRepository.ask(input, conversationHistory.toList())
        if (response.success) {
            conversationHistory.add(ChatMessage("user", input))
            conversationHistory.add(ChatMessage("assistant", response.text))
            if (conversationHistory.size > 32) conversationHistory.removeAt(0)
            showAssistantResponse(response.text)
        } else {
            showError(response.errorMessage ?: "AI service is unavailable. Configure the backend in Settings.")
        }
    }

    private fun showAssistantResponse(message: String) {
        state = state.copy(
            response = message,
            isProcessing = false,
            statusMessage = "JARVIS is ready",
            errorMessage = null,
            conversation = state.conversation + ConversationMessage(message, false)
        )
    }

    private fun showError(message: String) {
        state = state.copy(
            response = message,
            isProcessing = false,
            statusMessage = "Needs attention",
            errorMessage = message,
            conversation = state.conversation + ConversationMessage(message, false)
        )
    }

    fun setListening(value: Boolean) {
        state = state.copy(isListening = value, statusMessage = if (value) "Listening..." else "JARVIS is ready")
    }

    fun setSpeaking(value: Boolean) {
        state = state.copy(isSpeaking = value, statusMessage = if (value) "JARVIS is speaking..." else "JARVIS is ready")
    }

    fun saveNote(key: String, value: String) {
        localStorage.saveNote(key, value)
        showAssistantResponse("Your note has been saved.")
    }

    fun getSavedNote(key: String): String? = localStorage.getNote(key)

    fun clearConversation() {
        conversationHistory.clear()
        state = JarvisState(statusMessage = "Conversation cleared")
    }
}
