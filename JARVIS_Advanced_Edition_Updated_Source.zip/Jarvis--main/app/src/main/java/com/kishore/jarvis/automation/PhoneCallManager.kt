package com.kishore.jarvis.automation

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class PhoneActionResult(val success: Boolean, val message: String)

class PhoneCallManager(private val context: Context) {
    fun findContactNumber(contactName: String): String? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED || contactName.isBlank()) return null
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(contactName.trim()))
        return try {
            context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.NUMBER), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    fun openDialer(phoneNumber: String): PhoneActionResult {
        if (phoneNumber.isBlank()) return PhoneActionResult(false, "I could not find a valid phone number.")
        return try {
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phoneNumber)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            PhoneActionResult(true, "Dialer opened. Please review the number and press Call yourself.")
        } catch (_: Exception) { PhoneActionResult(false, "Unable to open the phone dialer.") }
    }

    fun callContact(contactName: String): PhoneActionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return PhoneActionResult(false, "Contacts permission is needed. Grant it in Android Settings, then try again.")
        }
        val number = findContactNumber(contactName)
            ?: return PhoneActionResult(false, "I couldn't find a phone number for $contactName.")
        return openDialer(number)
    }
}
