package com.kishore.jarvis.automation

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && body.isBlank()) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = runCatching { JSONArray(prefs.getString(KEY_ITEMS, "[]") ?: "[]") }.getOrDefault(JSONArray())
        val next = JSONArray()
        next.put(JSONObject().put("app", sbn.packageName).put("title", title).put("text", body).put("time", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 48)) next.put(old.getJSONObject(i))
        prefs.edit().putString(KEY_ITEMS, next.toString()).apply()
    }

    companion object {
        private const val PREFS = "jarvis_notifications"
        private const val KEY_ITEMS = "items"

        fun hasAccess(context: Context): Boolean {
            val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
            return enabled.contains(context.packageName)
        }

        fun recent(context: Context, limit: Int = 10): String {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]")
            val array = runCatching { JSONArray(raw.orEmpty()) }.getOrDefault(JSONArray())
            if (array.length() == 0) return "I haven't stored any notifications yet. Enable notification access and wait for new notifications."
            return (0 until minOf(array.length(), limit)).joinToString("\n") { i ->
                val item = array.getJSONObject(i)
                "${item.optString("app")}: ${item.optString("title")} — ${item.optString("text")}"
            }
        }
    }
}
